<?php
/**
 *  @author    Payson AB <integration@payson.se>
 *  @copyright 2019 Payson AB
 *  @license   http://unlicense.org/
 */

namespace Payson\Payments\Exception;

/**
 * Class PaysonException
 * @package Payson\Payments\Exception
 */
class PaysonException extends \Exception
{
    
}
